# Node Football Tweeter

## Description

This project utilizes multiple APIs in order to tweet the current days football games accross the major leagues in EU.

## Technologies

-   Node
-   Node Fetch
-   Twitter lite
-   Twitter API
-   Football Data API
